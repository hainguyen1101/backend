package com.amazonaws.lambda.demo;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class LambdaFunctionHandler implements RequestHandler<Object, String> {

	private static String PUBLIC_KEY_STRING = "";
	private static String PRIVATE_KEY_STRING = "";
	private static PublicKey publicKey;
	private static PrivateKey privateKey;

	public LambdaFunctionHandler() {
	}

	@Override
	public String handleRequest(Object event, Context context) {
		// Creating KeyPair generator object
		KeyPairGenerator keyPairGen;
		try {
			keyPairGen = KeyPairGenerator.getInstance("RSA");
			// Initializing the KeyPairGenerator
			keyPairGen.initialize(4096);

			// Generating the pair of keys
			KeyPair pair = keyPairGen.generateKeyPair();

			// Getting the private key from the key pair
			privateKey = pair.getPrivate();
			// converting byte to String
			byte[] bytePrikey = privateKey.getEncoded();
			String strKey = Base64.getEncoder().encodeToString(bytePrikey);
			PRIVATE_KEY_STRING = Base64.getEncoder().encodeToString(bytePrikey);
			System.out.println("\nSTRING PRIVATE_KEY:" + strKey);

			// ==================================
			// Getting the public key from the key pair
			publicKey = pair.getPublic();
			// converting byte to String
			byte[] bytePubkey = publicKey.getEncoded();
			String strPubKey = Base64.getEncoder().encodeToString(bytePubkey);
			PUBLIC_KEY_STRING = Base64.getEncoder().encodeToString(bytePubkey);
			System.out.println("\nSTRING PUBLIC_KEY:" + strPubKey);
			updateKeyPair(PUBLIC_KEY_STRING, PRIVATE_KEY_STRING, "http://google12312123.com");
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return null;
	}

	public void updateKeyPair(String publicKey, String privateKey, String siteUrl) {
		String sqlInsertLog = "UPDATE atmos_auth_db.sites SET public_key = ?, private_key = ? WHERE site_url = ?";
		String connectionUrl = "jdbc:mysql://atmos-db-dev.cnszrv4ba9ox.ap-northeast-1.rds.amazonaws.com:3306/atmos?useSSL=false";
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");  
//		} catch (ClassNotFoundException e1) {
//			e1.printStackTrace();
//		}
		try (Connection conn = DriverManager.getConnection(connectionUrl, "root", "Atmos124");
				PreparedStatement ps2 = conn.prepareStatement(sqlInsertLog);) {
			// Set the values
			ps2.setString(1, publicKey);
			ps2.setString(2, privateKey);
			ps2.setString(3, siteUrl);
			ps2.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}