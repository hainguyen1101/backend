package demo1;

public class HttpFormatException extends Exception {
	private static final long serialVersionUID = 2466383400971617206L;

	public HttpFormatException(final String msg) {
		super(msg);
	}
}