package demo1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.Socket;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import redis.clients.jedis.Jedis;

public class EchoThread extends Thread {
//	private static final String PRIVATE_KEY_STRING = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJhBgzcXBm5A0srvFFu4FsBy+LLW+X0sH/9RvP40VIGOCusY0/CqA65YXWqyQE5jQCegBmnAeVYSvK+3PU4Y1fmr1uiquE6sZB5sl96T0ka+PKzPf4oKoAi6nwLUSenj5xTFjLsFGiuMXrCpMCPImf9JBVk89TJV43Xs3DSNKoj1AgMBAAECgYBsDysCgVv2ChnRH4eSZP/4zGCIBR0C4rs+6RM6U4eaf2ZuXqulBfUg2uRKIoKTX8ubk+6ZRZqYJSo3h9SBxgyuUrTehhOqmkMDo/oa9v7aUqAKw/uoaZKHlj+3p4L3EK0ZBpz8jjs/PXJc77Lk9ZKOUY+T0AW2Fz4syMaQOiETzQJBANF5q1lntAXN2TUWkzgir+H66HyyOpMu4meaSiktU8HWmKHa0tSB/v7LTfctnMjAbrcXywmb4ddixOgJLlAjEncCQQC6Enf3gfhEEgZTEz7WG9ev/M6hym4C+FhYKbDwk+PVLMVR7sBAtfPkiHVTVAqC082E1buZMzSKWHKAQzFL7o7zAkBye0VLOmLnnSWtXuYcktB+92qh46IhmEkCCA+py2zwDgEiy/3XSCh9Rc0ZXqNGD+0yQV2kpb3awc8NZR8bit9nAkBo4TgVnoCdfbtq4BIvBQqR++FMeJmBuxGwv+8n63QkGFQwVm6vCuAqFHBtQ5WZIGFbWk2fkKkwwaHogfcrYY/ZAkEAm5ibtJx/jZdPEF9VknswFTDJl9xjIfbwtUb6GDMc0KH7v+QTBW4GsHwt/gL+kGvLOLcEdLL5rau3IC7EQT0ZYg==";
	private static String PRIVATE_KEY_STRING = "";
	private PrivateKey privateKey;
	protected Socket socket;
	private static SecretKey sessionKey;
	private static String algorithm = "AES";
//	private final static String REDIS_HOST = "dev-atmos-redis1.cdq9yn.ng.0001.apne1.cache.amazonaws.com";
	private final static String REDIS_HOST = "localhost";
	private final static String END_LINE_CHARACTER = "\r\n";
	private static final Log log = LogFactory.getLog(EchoThread.class);

	public EchoThread(Socket clientSocket) {
		this.socket = clientSocket;
		_requestHeaders = new Hashtable<String, String>();
		_messagetBody = new StringBuffer();
	}

	// one instance, reuse
	private final CloseableHttpClient httpClient = HttpClients.createDefault();

	public void run() {
		log.info("bbbb");
		InputStream sslIS;
		try {
			sslIS = socket.getInputStream();
			OutputStream sslOS = socket.getOutputStream();
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			// Read from the Client
			BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(sslIS));
			sslOS.write("connected".concat(END_LINE_CHARACTER).getBytes());
			sslOS.flush();

			String inputLine;
			inputLine = bufferedreader.readLine();
			System.out.println("all parameter: " + inputLine);

			String[] arrayParameter = inputLine.split(",");
			String deviceId = arrayParameter[1].split("=")[1];
			String siteUrl = arrayParameter[2].split("=")[1];
			String beforeSessionKey = arrayParameter[3].split("=")[1];

			int checkSiteResult = checkSite(deviceId, siteUrl);
			System.out.println("check site url:" + checkSiteResult);
			if (checkSiteResult == 404) {
				sslOS.write("status_code=404,message=Not found. The site_url is not found.".concat(END_LINE_CHARACTER)
						.getBytes());
				sslOS.flush();
				return;
			}
			if (checkSiteResult == 401) {
				sslOS.write("status_code=401,message=Unauthorized. device_id is not allow to access to the site."
						.concat(END_LINE_CHARACTER).getBytes());
				sslOS.flush();
				return;
			}

			if (checkSiteResult == 200) {
				try {
					initFromStrings();
					byte[] decodedSessionKey = Base64.getDecoder().decode(decrypt(beforeSessionKey));
					System.out.println("sessionKey=" + decrypt(beforeSessionKey));
				} catch (Exception e) {
					sslOS.write("status_code=422,message=Cannot decrypt session_key.".concat(END_LINE_CHARACTER)
							.getBytes());
					sslOS.flush();
					return;
				}
				UUID uuid = UUID.randomUUID();
				sslOS.write(("status_code=200,message=Success,session_id=" + uuid.toString()).concat(END_LINE_CHARACTER)
						.getBytes());
				sslOS.flush();
				saveToRedis(uuid.toString(), decrypt(beforeSessionKey));
			}
//			Read text
//			while ((inputLine = bufferedreader.readLine()) != null) {
//				String[] arrayParameter2 = inputLine.split(",");
//				String sessionId = arrayParameter2[1].split("=")[1];
//				String data = arrayParameter2[2].split("=")[1];
//				System.out.println("encrypt data=" + data);
//				if (arrayParameter2[0].split("=")[1].equals("dataTransfer")) {
//					byte[] decodedSessionKey = Base64.getDecoder().decode(getSessionKey(sessionId));
//					sessionKey = new SecretKeySpec(decodedSessionKey, 0, decodedSessionKey.length, "AES");
//				}
//				String descryptData = decryptBySessionKey(algorithm, data, sessionKey);
//				System.out.println("original data=" + descryptData);
//			}
//			read request
			while ((inputLine = bufferedreader.readLine()) != null) {
				String[] arrayParameter2 = inputLine.split(",");
				String sessionId = arrayParameter2[1].split("=")[1];
				String data = arrayParameter2[2].split("=")[1];
				System.out.println("encrypt data=" + data);
				if (arrayParameter2[0].split("=")[1].equals("dataTransfer")) {
					System.out.println(getSessionKey(sessionId));
					byte[] decodedSessionKey = Base64.getDecoder().decode(getSessionKey(sessionId));
					sessionKey = new SecretKeySpec(decodedSessionKey, 0, decodedSessionKey.length, "AES");
				}
				writeLog(siteUrl, deviceId);
				String plainText = decryptBySessionKey(algorithm, data, sessionKey);
				System.out.println(plainText);
				parseRequest(plainText);
				System.out.println(get_requestLine());
				System.out.println(get_requestHeaders());
				System.out.println(get_messagetBody());

				String methodType = _requestLine.split(" ")[0];
				String apiUrl = _requestLine.split(" ")[1];
				String host = _requestHeaders.get("Host").trim();
				try {
					String dataResponse;
					switch (methodType) {
					case "POST":
						dataResponse = encryptBySessionKey(algorithm, sendPost(host + apiUrl, _messagetBody.toString()),
								sessionKey);
						sslOS.write(("status_code=200,message=Success,response=" + dataResponse)
								.concat(END_LINE_CHARACTER).getBytes());
						sslOS.flush();
						break;
					case "PUT":
						dataResponse = encryptBySessionKey(algorithm, sendPost(host + apiUrl, _messagetBody.toString()),
								sessionKey);
						sslOS.write(("status_code=200,message=Success,response=" + dataResponse)
								.concat(END_LINE_CHARACTER).getBytes());
						sslOS.flush();
						break;
					case "GET":
						dataResponse = encryptBySessionKey(algorithm, sendGet(host + apiUrl, _requestHeaders),
								sessionKey);
						sslOS.write(("status_code=200,message=Success,response=" + dataResponse)
								.concat(END_LINE_CHARACTER).getBytes());
						sslOS.flush();
						break;
					case "DELETE":
						dataResponse = encryptBySessionKey(algorithm, sendDelete(host + apiUrl, _requestHeaders),
								sessionKey);
						sslOS.write(("status_code=200,message=Success,response=" + dataResponse)
								.concat(END_LINE_CHARACTER).getBytes());
						sslOS.flush();
						break;
					default:
						break;
					}
				} finally {
//					httpClient.close();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private String sendGet(String url, Hashtable<String, String> _requestHeaders) throws Exception {
		HttpGet request = new HttpGet(url);
		String result = "";
		// add request headers
		Iterator<String> keys = (Iterator<String>) _requestHeaders.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			if (_requestHeaders.get(key) instanceof String && !key.equals("Host")) {
				request.addHeader(key, _requestHeaders.get(key));
			}
		}
		try (CloseableHttpResponse response = httpClient.execute(request)) {

			// Get HttpResponse Status
//			System.out.println(response.getStatusLine().toString());

			HttpEntity entity = response.getEntity();
			Header headers = entity.getContentType();
			System.out.println(headers);

			if (entity != null) {
				// return it as a String
				result = EntityUtils.toString(entity);
//				System.out.println(result);
			}
		}
		return result;
	}

	private String sendDelete(String url, Hashtable<String, String> _requestHeaders) throws Exception {

		HttpGet request = new HttpGet(url);
		String result = "";
		// add request headers
		Iterator<String> keys = (Iterator<String>) _requestHeaders.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			if (_requestHeaders.get(key) instanceof String && !key.equals("Host")) {
				request.addHeader(key, _requestHeaders.get(key));
			}
		}
		try (CloseableHttpResponse response = httpClient.execute(request)) {

			// Get HttpResponse Status
//			System.out.println(response.getStatusLine().toString());

			HttpEntity entity = response.getEntity();
			Header headers = entity.getContentType();
			System.out.println(headers);

			if (entity != null) {
				// return it as a String
				result = EntityUtils.toString(entity);
//				System.out.println(result);
			}
		}
		return result;
	}

	private String sendPost(String url, String messageBody) throws Exception {
		// add request parameter, form parameters
		List<NameValuePair> urlParameters = new ArrayList<>();
		JSONObject jsonObject = new JSONObject(messageBody);
		Iterator<String> keys = jsonObject.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			if (jsonObject.get(key) instanceof String) {
				urlParameters.add(new BasicNameValuePair(key, jsonObject.get(key).toString()));
			}
		}
		HttpPost post = new HttpPost(url);

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		try (CloseableHttpClient httpClient = HttpClients.createDefault();
				CloseableHttpResponse response = httpClient.execute(post)) {
			return EntityUtils.toString(response.getEntity());
//			System.out.println(EntityUtils.toString(response.getEntity()));
		}
	}

	private String sendPut(String url, String messageBody) throws Exception {
		// add request parameter, form parameters
		List<NameValuePair> urlParameters = new ArrayList<>();
		JSONObject jsonObject = new JSONObject(messageBody);
		Iterator<String> keys = jsonObject.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			if (jsonObject.get(key) instanceof String) {
				urlParameters.add(new BasicNameValuePair(key, jsonObject.get(key).toString()));
			}
		}
		HttpPut post = new HttpPut(url);

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		try (CloseableHttpClient httpClient = HttpClients.createDefault();
				CloseableHttpResponse response = httpClient.execute(post)) {
			return EntityUtils.toString(response.getEntity());
//			System.out.println(EntityUtils.toString(response.getEntity()));
		}
	}

	private String sendPostUploadFile(String url, String messageBody) throws Exception {
		HttpPost post = new HttpPost(url);
		File file = new File("C:\\Users\\Admin\\Downloads\\server-dummy\\1.txt");
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		FileBody bin = new FileBody(file);
		builder.addPart("file", bin);
		HttpEntity multipart = builder.build();
		post.setEntity(multipart);
		try (CloseableHttpClient httpClient = HttpClients.createDefault();
				CloseableHttpResponse response = httpClient.execute(post)) {
			return EntityUtils.toString(response.getEntity());
//			System.out.println(EntityUtils.toString(response.getEntity()));
		}
	}

	public void writeLog(String siteUrl, String deviceId) {
		String sqlSelectSite = "SELECT * FROM atmos_auth_db.sites where site_url = ?";
		String sqlInsertLog = "INSERT INTO atmos_auth_db.logs (site_id, device_id,created_at) VALUES (?, ?, now())";
		String connectionUrl = "jdbc:mysql://atmos-db-dev.cnszrv4ba9ox.ap-northeast-1.rds.amazonaws.com:3306/atmos";

		try (Connection conn = DriverManager.getConnection(connectionUrl, "root", "Atmos124");
				PreparedStatement ps1 = conn.prepareStatement(sqlSelectSite);
				PreparedStatement ps2 = conn.prepareStatement(sqlInsertLog);) {
			// Set the values
//			ps.setString(1, "firstString");
//			ps.setString(2, "secondString");
			ps1.setString(1, siteUrl);
			ResultSet rs = ps1.executeQuery();
			int siteId = 0;
			while (rs.next()) {
				siteId = rs.getInt("id");
			}
			ps2.setInt(1, siteId);
			ps2.setString(2, deviceId);
			ps2.executeUpdate();
		} catch (SQLException e) {
			// handle the exception
			e.printStackTrace();
		}
	}

	public int checkSite(String deviceId, String siteUrl) {
		String sqlSelectSite = "SELECT * FROM atmos_auth_db.sites where site_url = ?";
		String connectionUrl = "jdbc:mysql://atmos-db-dev.cnszrv4ba9ox.ap-northeast-1.rds.amazonaws.com:3306/atmos";

		try (Connection conn = DriverManager.getConnection(connectionUrl, "root", "Atmos124");
				PreparedStatement ps = conn.prepareStatement(sqlSelectSite);) {
			ps.setString(1, siteUrl);
			try (ResultSet rs = ps.executeQuery()) {
				int size = 0;
				while (rs.next()) {
					PRIVATE_KEY_STRING = rs.getString("private_key");
					size++;
					boolean isLimited = rs.getBoolean("is_limited");
					if (!isLimited)
						return 200;
					long id = rs.getLong("id");
					String sqlGetListDeviceId = "SELECT * FROM atmos.devices where site_id = ?";
					try (PreparedStatement ps2 = conn.prepareStatement(sqlGetListDeviceId);) {
						ps2.setLong(1, id);
						try (ResultSet rs2 = ps2.executeQuery()) {
							int sizeDevices = 0;
							while (rs2.next()) {
								sizeDevices++;
							}
							if (sizeDevices > 0)
								return 200;
							return 401;
						}
					}
				}
				if (size == 0) {
					return 404;
				}

			}
		} catch (SQLException e) {
			// handle the exception
		}
		return 200;
	}

	public void initFromStrings() {
		try {
			PKCS8EncodedKeySpec keySpecPrivate = new PKCS8EncodedKeySpec(decode(PRIVATE_KEY_STRING));

			KeyFactory keyFactory = KeyFactory.getInstance("RSA");

			privateKey = keyFactory.generatePrivate(keySpecPrivate);
		} catch (Exception ignored) {
		}
	}

	public String decrypt(String encryptedMessage) throws Exception {
		byte[] encryptedBytes = decode(encryptedMessage);
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
		return new String(decryptedMessage, "UTF8");
	}

	private static byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}

	public static String decryptBySessionKey(String algorithm, String cipherText, SecretKey key)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(cipherText));
		return new String(plainText);
	}

	public SecretKey generateSessionKey(int i) throws NoSuchAlgorithmException {
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		keyGen.init(i);
		sessionKey = keyGen.generateKey();
		return sessionKey;
	}

	private String _requestLine;
	private Hashtable<String, String> _requestHeaders;
	private StringBuffer _messagetBody;

	/**
	 * Parse and HTTP request.
	 * 
	 * @param request String holding http request.
	 * @throws IOException         If an I/O error occurs reading the input stream.
	 * @throws HttpFormatException If HTTP Request is malformed
	 */
	public void parseRequest(String request) throws IOException, HttpFormatException {
		BufferedReader reader = new BufferedReader(new StringReader(request));

		setRequestLine(reader.readLine()); // Request-Line ; Section 5.1

		String header = reader.readLine();
		while (header != null && header.length() > 0) {
			appendHeaderParameter(header);
			header = reader.readLine();
		}

		String bodyLine = reader.readLine();
		while (bodyLine != null) {
			appendMessageBody(bodyLine);
			bodyLine = reader.readLine();
		}

	}

	/**
	 * 
	 * 5.1 Request-Line The Request-Line begins with a method token, followed by the
	 * Request-URI and the protocol version, and ending with CRLF. The elements are
	 * separated by SP characters. No CR or LF is allowed except in the final CRLF
	 * sequence.
	 * 
	 * @return String with Request-Line
	 */
	public String getRequestLine() {
		return _requestLine;
	}

	private void setRequestLine(String requestLine) throws HttpFormatException {
		if (requestLine == null || requestLine.length() == 0) {
			throw new HttpFormatException("Invalid Request-Line: " + requestLine);
		}
		_requestLine = requestLine;
	}

	private void appendHeaderParameter(String header) throws HttpFormatException {
		int idx = header.indexOf(":");
		if (idx == -1) {
			throw new HttpFormatException("Invalid Header Parameter: " + header);
		}
		_requestHeaders.put(header.substring(0, idx), header.substring(idx + 1, header.length()));
	}

	/**
	 * The message-body (if any) of an HTTP message is used to carry the entity-body
	 * associated with the request or response. The message-body differs from the
	 * entity-body only when a transfer-coding has been applied, as indicated by the
	 * Transfer-Encoding header field (section 14.41).
	 * 
	 * @return String with message-body
	 */
	public String getMessageBody() {
		return _messagetBody.toString();
	}

	private void appendMessageBody(String bodyLine) {
		_messagetBody.append(bodyLine).append("\r\n");
	}

	public String get_requestLine() {
		return _requestLine;
	}

	public void set_requestLine(String _requestLine) {
		this._requestLine = _requestLine;
	}

	public Hashtable<String, String> get_requestHeaders() {
		return _requestHeaders;
	}

	public void set_requestHeaders(Hashtable<String, String> _requestHeaders) {
		this._requestHeaders = _requestHeaders;
	}

	public StringBuffer get_messagetBody() {
		return _messagetBody;
	}

	public void set_messagetBody(StringBuffer _messagetBody) {
		this._messagetBody = _messagetBody;
	}

	/**
	 * For list of available headers refer to sections: 4.5, 5.3, 7.1 of RFC 2616
	 * 
	 * @param headerName Name of header
	 * @return String with the value of the header or null if not found.
	 */
	public String getHeaderParam(String headerName) {
		return _requestHeaders.get(headerName);
	}

	public void saveToRedis(String key, String value) {
		try (Jedis jedis = new Jedis(REDIS_HOST, 6379)) {
			jedis.set(key, value);
			jedis.expire(key, 1000);
		}
	}

	private String getSessionKey(String sessionId) {
		try (Jedis jedis = new Jedis(REDIS_HOST, 6379)) {
			return jedis.get(sessionId);
		}
	}

	public static String encryptBySessionKey(String algorithm, String input, SecretKey key)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] cipherText = cipher.doFinal(input.getBytes());
		return Base64.getEncoder().encodeToString(cipherText);
	}
}