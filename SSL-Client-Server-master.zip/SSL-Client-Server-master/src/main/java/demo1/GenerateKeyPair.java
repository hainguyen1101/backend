package demo1;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

public class GenerateKeyPair {
	private static String PUBLIC_KEY_STRING = "";
	private static String PRIVATE_KEY_STRING = "";
	private static PublicKey publicKey;
	private static PrivateKey privateKey;
	
	public static void main(String[] args) throws NoSuchAlgorithmException {
		// Creating KeyPair generator object
		KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");

		// Initializing the KeyPairGenerator
		keyPairGen.initialize(2048);

		// Generating the pair of keys
		KeyPair pair = keyPairGen.generateKeyPair();

		// Getting the private key from the key pair
		privateKey = pair.getPrivate();
		// converting byte to String
		byte[] bytePrikey = privateKey.getEncoded();
		String strKey = Base64.getEncoder().encodeToString(bytePrikey);
		PRIVATE_KEY_STRING = Base64.getEncoder().encodeToString(bytePrikey);
		System.out.println("\nSTRING PRIVATE_KEY:" + strKey);

		// ==================================
		// Getting the public key from the key pair
		publicKey = pair.getPublic();
		// converting byte to String
		byte[] bytePubkey = publicKey.getEncoded();
		String strPubKey = Base64.getEncoder().encodeToString(bytePubkey);
		PUBLIC_KEY_STRING = Base64.getEncoder().encodeToString(bytePubkey);
		System.out.println("\nSTRING PUBLIC_KEY:" + strPubKey);
		new GenerateKeyPair().initFromStrings();
		try {
			String enStr = new GenerateKeyPair().encrypt("aaa");
			System.out.println(enStr);
			System.out.println(new GenerateKeyPair().decrypt(enStr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void initFromStrings() {
		try {
			X509EncodedKeySpec keySpecPublic = new X509EncodedKeySpec(decode(PUBLIC_KEY_STRING));
			PKCS8EncodedKeySpec keySpecPrivate = new PKCS8EncodedKeySpec(decode(PRIVATE_KEY_STRING));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");

			publicKey = keyFactory.generatePublic(keySpecPublic);
			privateKey = keyFactory.generatePrivate(keySpecPrivate);
			System.out.println(Base64.getEncoder().encodeToString(publicKey.getEncoded()));
			System.out.println(Base64.getEncoder().encodeToString(privateKey.getEncoded()));
		} catch (Exception ignored) {
			ignored.printStackTrace();
		}
	}
	private static String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}
	private static byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}
	public String encrypt(String message) throws Exception {
		byte[] messageToBytes = message.getBytes("UTF-8");
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedBytes = cipher.doFinal(messageToBytes);
		return encode(encryptedBytes);
	}
	public String decrypt(String encryptedMessage) throws Exception {
		byte[] encryptedBytes = decode(encryptedMessage);
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
		return new String(decryptedMessage, "UTF8");
	}
}
