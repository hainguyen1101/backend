package demo1;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MyClient6 {
	private PublicKey publicKey;
	private static final String PUBLIC_KEY_STRING = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYQYM3FwZuQNLK7xRbuBbAcviy1vl9LB//Ubz+NFSBjgrrGNPwqgOuWF1qskBOY0AnoAZpwHlWEryvtz1OGNX5q9boqrhOrGQebJfek9JGvjysz3+KCqAIup8C1Enp4+cUxYy7BRorjF6wqTAjyJn/SQVZPPUyVeN17Nw0jSqI9QIDAQAB";
	private static SecretKey sessionKey;
	private static String algorithm = "AES";
	private static String sessionId = "";
	private final static String END_LINE_CHARACTER = "\r\n";

	public static void main(String[] args) {
		MyClient6 rsa = new MyClient6();
		rsa.initFromStrings();
		try {
			Socket s = new Socket("localhost", 7777);
			InputStream sslIS = s.getInputStream();
			OutputStream sslOS = s.getOutputStream();
			PrintWriter out = new PrintWriter(s.getOutputStream(), true);
			// Read from the Server
			BufferedReader in = new BufferedReader(new InputStreamReader(sslIS));
			String fromServer;
			sessionKey = rsa.generateSessionKey(128);
			// get base64 encoded version of the key
			String encodedKey = Base64.getEncoder().encodeToString(sessionKey.getEncoded());
			System.out.println("encodedKey: " + encodedKey);
			fromServer = in.readLine();
			System.out.println(fromServer);
			if (fromServer.equals("connected")) {
				String atmosSocket01 = "type=keyExchange,device_id=ede66c43-9b9d-4222-93ed-5f11c96e08e2,site_url=http://dev-hesta-platform-2095811784.ap-northeast-1.elb.amazonaws.com,session_key="
						+ rsa.encrypt(encodedKey);
				sslOS.write(atmosSocket01.concat(END_LINE_CHARACTER).getBytes());
				sslOS.flush();
			}
			fromServer = in.readLine();
			System.out.println(fromServer);
			System.out.println(fromServer.split(",")[0].split("=")[1]);
			if (fromServer.split(",")[0].split("=")[1].equals("422")
					|| fromServer.split(",")[0].split("=")[1].equals("404")
					|| fromServer.split(",")[0].split("=")[1].equals("401")
					|| fromServer.split(",")[0].split("=")[1].equals("400")) {
				sslOS.close();
				s.close();
				return;
			}
			sessionId = fromServer.split(",")[2].split("=")[1];
			System.out.println(sessionId);
			// send text data
//			String data = "saaaaaaaaaaaaaaaaa";
//			String encryptedData = rsa.encryptBySessionKey(algorithm, data, sessionKey);
//			String atmosSocket02 = "type=dataTransfer,session_id=" + sessionId + ",data=" + encryptedData;
//			System.out.println(atmosSocket02);
//			out.println(atmosSocket02);
//
//			String data2 = "bbbbbbb";
//			String encryptedData2 = rsa.encryptBySessionKey(algorithm, data2, sessionKey);
//			String atmosSocket03 = "type=dataTransfer,session_id=" + sessionId + ",data=" + encryptedData2;
//			System.out.println(atmosSocket03);
//			out.println(atmosSocket03);

			// send http post
			sslOS.write(("type=dataTransfer,session_id=" + sessionId + ",data="
					+ rsa.encryptBySessionKey(algorithm, "POST /v1/auth/login HTTP/1.1\r\n"
							+ "Host: http://dev-hesta-platform-2095811784.ap-northeast-1.elb.amazonaws.com\r\n"
							+ "Accept:application/json\r\nContent-Type:application/json\r\n\r\n"
							+ "{\"type\": \"mail\", \"password\": \"qwerty123\", \"username\": \"atmos@gmail.com\"}",
							sessionKey)).concat(END_LINE_CHARACTER).getBytes());
			sslOS.flush();
			fromServer = in.readLine();
			System.out.println(fromServer);
			String dataResponse = decryptBySessionKey(algorithm, fromServer.split(",")[2].split("=")[1], sessionKey);
			System.out.println(dataResponse);
//			send http get
			sslOS.write(("type=dataTransfer,session_id=" + sessionId + ",data="
					+ rsa.encryptBySessionKey(algorithm, "GET /v1/users/123 HTTP/1.1\r\n"
							+ "Host: http://dev-hesta-platform-2095811784.ap-northeast-1.elb.amazonaws.com\r\n"
							+ "Accept:application/json\r\nContent-Type:application/json\r\nAuthorization:Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIyIiwianRpIjoiYTRkYzZhZWViMTJhZWY2OTE2NzEyNWE0M2I3MTVlYjM4YmQxNjllOTI1OGZjMjFjMDljYjVhMTk0MzIwOTBiMDliYTBmMDFiNTFjNzlkZGUiLCJpYXQiOjE2NTA3Mjk4NjYsIm5iZiI6MTY1MDcyOTg2NiwiZXhwIjoxNjUwODE2MjY2LCJzdWIiOiIyODgiLCJzY29wZXMiOlsidXNlciJdfQ.GefpOjnMq9ydco3QgvPOqnEI7_AG4sv0tRDF-PjAd8lN8-IF6r4NITUjZ-ZoKeqFSl0jCksrpO4lLelT2_YRdOEiiER1sghPBim57k75PgQWlph0wo0PdXyx4B5EMTXcIkTh2OuEZSsVEsRthxOvb-8qWcfxF6epb2V8yAmR4xoLUqnKPS5pTy1QnryjyotqwvJ07OJp7QYXPiN6qGFI0u4HBXNFIW0Fhtn17JYuIaIWlXYZiJ3Z9sJ4e2x9YhMnmtSo27eiHIk6_QLbR_nekIKcEitRlkYv1ByB0whydUDtQ0SYzyj93u9aGIJn_DgFnHfTqRYOxssFZmo9-ibL8rvqOBS6gH2JprdPJRMh6l5JSqjDzW9XI_cM6_Y6yV65F4WRATRAc4zLzPzxBGXD660cVn4_vvlsjbHMFiYRso188H2J1O4n61FEpIoqdR3zWsg9lXGiOyWMlTkkMDhr3KO9SpIyei3JS_l4Ks3Zwg8Dmg__6xjC6Iy_qVOQsG5zNivbHeJT6rgJ2v4oGjoY7iCGKiySLJ48mJehU7iefE2fLUJ83Kx71w_y1_DS3ZhZDM2AdFH0FI_eRlmmGIh8YxH86OMtbWNDpQ6x-ClTaARDAk3X3cNYxC_XCW5Qkjo9T3cOntM7zrqfJBJ5RkGvsEkJfndPORrhEsFzx_Bl43E \r\n\r\n",
							sessionKey)).concat(END_LINE_CHARACTER).getBytes());
			sslOS.flush();
			fromServer = in.readLine();
			System.out.println(fromServer);
			dataResponse = decryptBySessionKey(algorithm, fromServer.split(",")[2].split("=")[1], sessionKey);
			System.out.println(dataResponse);
////			send http get download file
//			sslOS.write(("type=dataTransfer,session_id=" + sessionId + ",data="
//					+ rsa.encryptBySessionKey(algorithm,
//							"GET /download?fileName=1.txt HTTP/1.1\r\n" + "Host: http://localhost:8080\r\n"
//									+ "Accept:application/json\r\nContent-Type:application/json\r\n\r\n",
//							sessionKey)).concat(END_LINE_CHARACTER).getBytes());
//			sslOS.flush();
//			fromServer = in.readLine();
//			System.out.println(fromServer);
//			String dataResponse = decryptBySessionKey(algorithm, fromServer.split(",")[2].split("=")[1], sessionKey);
//			System.out.println(dataResponse);
//			send http delete
			sslOS.write(("type=dataTransfer,session_id=" + sessionId + ",data="
					+ rsa.encryptBySessionKey(algorithm, "DELETE /v1/users/123 HTTP/1.1\r\n"
							+ "Host: http://dev-hesta-platform-2095811784.ap-northeast-1.elb.amazonaws.com\r\n"
							+ "Accept:application/json\r\nContent-Type:application/json\r\nAuthorization:Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIyIiwianRpIjoiYTRkYzZhZWViMTJhZWY2OTE2NzEyNWE0M2I3MTVlYjM4YmQxNjllOTI1OGZjMjFjMDljYjVhMTk0MzIwOTBiMDliYTBmMDFiNTFjNzlkZGUiLCJpYXQiOjE2NTA3Mjk4NjYsIm5iZiI6MTY1MDcyOTg2NiwiZXhwIjoxNjUwODE2MjY2LCJzdWIiOiIyODgiLCJzY29wZXMiOlsidXNlciJdfQ.GefpOjnMq9ydco3QgvPOqnEI7_AG4sv0tRDF-PjAd8lN8-IF6r4NITUjZ-ZoKeqFSl0jCksrpO4lLelT2_YRdOEiiER1sghPBim57k75PgQWlph0wo0PdXyx4B5EMTXcIkTh2OuEZSsVEsRthxOvb-8qWcfxF6epb2V8yAmR4xoLUqnKPS5pTy1QnryjyotqwvJ07OJp7QYXPiN6qGFI0u4HBXNFIW0Fhtn17JYuIaIWlXYZiJ3Z9sJ4e2x9YhMnmtSo27eiHIk6_QLbR_nekIKcEitRlkYv1ByB0whydUDtQ0SYzyj93u9aGIJn_DgFnHfTqRYOxssFZmo9-ibL8rvqOBS6gH2JprdPJRMh6l5JSqjDzW9XI_cM6_Y6yV65F4WRATRAc4zLzPzxBGXD660cVn4_vvlsjbHMFiYRso188H2J1O4n61FEpIoqdR3zWsg9lXGiOyWMlTkkMDhr3KO9SpIyei3JS_l4Ks3Zwg8Dmg__6xjC6Iy_qVOQsG5zNivbHeJT6rgJ2v4oGjoY7iCGKiySLJ48mJehU7iefE2fLUJ83Kx71w_y1_DS3ZhZDM2AdFH0FI_eRlmmGIh8YxH86OMtbWNDpQ6x-ClTaARDAk3X3cNYxC_XCW5Qkjo9T3cOntM7zrqfJBJ5RkGvsEkJfndPORrhEsFzx_Bl43E \r\n\r\n",
							sessionKey)).concat(END_LINE_CHARACTER).getBytes());
			sslOS.flush();
			fromServer = in.readLine();
			System.out.println(fromServer);
			dataResponse = decryptBySessionKey(algorithm, fromServer.split(",")[2].split("=")[1], sessionKey);
			System.out.println(dataResponse);
			sslOS.close();
			s.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void initFromStrings() {
		try {
			X509EncodedKeySpec keySpecPublic = new X509EncodedKeySpec(decode(PUBLIC_KEY_STRING));

			KeyFactory keyFactory = KeyFactory.getInstance("RSA");

			publicKey = keyFactory.generatePublic(keySpecPublic);
			System.out.println(Base64.getEncoder().encodeToString(publicKey.getEncoded()));
		} catch (Exception ignored) {
		}
	}

	public String encrypt(String message) throws Exception {
		byte[] messageToBytes = message.getBytes("UTF-8");
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedBytes = cipher.doFinal(messageToBytes);
		return encode(encryptedBytes);
	}

	private static String encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data);
	}

	private static byte[] decode(String data) {
		return Base64.getDecoder().decode(data);
	}

	public SecretKey generateSessionKey(int i) throws NoSuchAlgorithmException {
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		keyGen.init(i);
		sessionKey = keyGen.generateKey();
		return sessionKey;
	}

	public static String encryptBySessionKey(String algorithm, String input, SecretKey key)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] cipherText = cipher.doFinal(input.getBytes());
		return Base64.getEncoder().encodeToString(cipherText);
	}

	public static String decryptBySessionKey(String algorithm, String cipherText, SecretKey key)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(cipherText));
		return new String(plainText);
	}
}
