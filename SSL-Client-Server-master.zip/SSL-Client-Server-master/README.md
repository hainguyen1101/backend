#### Simple Java SSL/TSL Socket Server 

##### 1. What is the role of public key and private key

* Public key is used to encrypt information. 
* Private key is used to decrypt information. 

#### How to deploy
1. zip source code to SSL-Client-Server-master.zip
2. copy source to EC2
scp -i atmos-dev.pem D:\SSL-Client-Server-master.zip ec2-user@35.77.160.132:/usr/tmp
3. cd to folder SSL-Client-Server-master
4. run: mvn clean compile assembly:single
5. cd to target
6. Run server: java -jar JavaSecurity-1.0-SNAPSHOT-jar-with-dependencies.jar
7. Run client: cd to target/classes and run: java demo1.MyClient5
